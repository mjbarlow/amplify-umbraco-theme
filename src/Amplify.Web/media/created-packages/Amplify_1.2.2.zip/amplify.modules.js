﻿(function () {
    'use strict';
    angular.module('umbraco').requires.push('angularSpectrumColorpicker');
}());